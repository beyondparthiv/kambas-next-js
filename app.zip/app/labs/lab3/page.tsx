export default function Page() {
  return (
    <main style={{ padding: "20px", fontFamily: "Arial, sans-serif", lineHeight: "1.6" }}>
      <h1>Lab 3 - Landing Page</h1>
    </main>
  );
}