
export default function Inbox() { return <h1>Inbox</h1>; }
