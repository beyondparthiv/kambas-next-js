
export default function People() { return <h1>People</h1>; }
