import Link from "next/link";

export default function Grades() { return <h1>Grades</h1>; }
