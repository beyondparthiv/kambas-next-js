

export default function Piazza() { return <h1>Piazza</h1>; }
