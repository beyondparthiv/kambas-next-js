
export default function Zoom() { return <h1>Zoom</h1>; }
