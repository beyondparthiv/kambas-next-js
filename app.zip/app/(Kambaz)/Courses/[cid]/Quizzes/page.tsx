
export default function Quizzes() { return <h1>Quizzes</h1>; }
