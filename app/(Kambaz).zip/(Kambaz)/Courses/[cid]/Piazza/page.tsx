export default function Piazza() {
  return (
    <div id="wd-piazza">
      <h1>Piazza</h1>
      <p>
        Visit the class discussion forum at{" "}
        <a href="https://piazza.com/" target="_blank" rel="noreferrer">
          piazza.com
        </a>.
      </p>
    </div>
  );
}
