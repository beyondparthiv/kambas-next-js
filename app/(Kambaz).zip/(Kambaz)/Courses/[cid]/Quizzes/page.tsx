export default function Quizzes() {
  return (
    <div id="wd-quizzes">
      <h1>Quizzes</h1>
      <p>Coming soon.</p>
    </div>
  );
}
