"use client";

import { configureStore } from "@reduxjs/toolkit";

// These paths match your folder structure: Courses\[cid]\...
import coursesReducer from "./Courses/[cid]/reducer";
import modulesReducer from "./Courses/[cid]/Modules/reducer";
import assignmentsReducer from "./Courses/[cid]/Assignments/reducer";
import enrollmentsReducer from "./Enrollments/reducer"; // if you don't have this, comment it out

// Account slice we just fixed
import accountReducer from "./Store/accountReducer";

export const store = configureStore({
  reducer: {
    // keep these names to match existing code:
    coursesReducer,
    modulesReducer,
    assignmentsReducer,
    enrollmentsReducer,
    // account state will live at state.account
    account: accountReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
