"use client";

import { configureStore } from "@reduxjs/toolkit";

// IMPORT REAL REDUCERS
import coursesReducer from "../Courses/reducer";
import modulesReducer from "../Courses/Modules/reducer";
import assignmentsReducer from "../Courses/Assignments/reducer";
import accountReducer from "./accountReducer";

// TEMP enrollment reducer (REMOVE when you create real one)
import { createSlice } from "@reduxjs/toolkit";
const enrollmentsSlice = createSlice({
  name: "enrollments",
  initialState: [],
  reducers: {}
});

const store = configureStore({
  reducer: {
    courses: coursesReducer,
    modules: modulesReducer,
    assignments: assignmentsReducer,
    enrollments: enrollmentsSlice.reducer,
    account: accountReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
