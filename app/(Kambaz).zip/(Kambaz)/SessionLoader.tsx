"use client";

import { useEffect } from "react";
import { useDispatch } from "react-redux";
import axios from "axios";
import { setCurrentUser } from "./Store/reducer2";

export default function SessionLoader() {
  const dispatch = useDispatch();

  const loadSession = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_HTTP_SERVER}/api/users/profile`,
        {},
        { withCredentials: true }
      );
      dispatch(setCurrentUser(response.data));
    } catch (e) {
      // not logged in
      dispatch(setCurrentUser(null));
    }
  };

  useEffect(() => {
    loadSession();
  }, []);

  return null;
}
