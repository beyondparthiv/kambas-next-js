
import "../Account/index.css";

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return children;
}
