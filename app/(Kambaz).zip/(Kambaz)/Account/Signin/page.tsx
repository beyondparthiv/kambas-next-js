"use client";

import { useState } from "react";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import axios from "axios";

import { setCurrentUser } from "../../Store/accountReducer";
import AccountNav from "../Navigation";

export default function SigninPage() {
  const dispatch = useDispatch();
  const router = useRouter();

  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  });

  const signin = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_HTTP_SERVER}/api/users/signin`,
        credentials,
        { withCredentials: true }
      );

      const user = response.data;
      if (!user) return;

      // store user in Redux
      dispatch(setCurrentUser(user));

      // go to dashboard
      router.push("/Kambaz/Dashboard");
    } catch (e) {
      alert("Invalid username or password");
    }
  };

  return (
    <div id="wd-account-shell">
      <AccountNav active="Signin" />

      <main id="wd-account-main" className="wd-auth">
        <h1>Signin</h1>

        <input
          className="form-control mb-2"
          placeholder="username"
          value={credentials.username}
          onChange={(e) =>
            setCredentials({ ...credentials, username: e.target.value })
          }
        />

        <input
          className="form-control mb-3"
          placeholder="password"
          type="password"
          value={credentials.password}
          onChange={(e) =>
            setCredentials({ ...credentials, password: e.target.value })
          }
        />

        <button onClick={signin} className="btn btn-primary">
          Signin
        </button>
      </main>
    </div>
  );
}
